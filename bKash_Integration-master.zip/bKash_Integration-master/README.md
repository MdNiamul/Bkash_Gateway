Bkash Payment Gateway Integration Android & PHP বিকাশ পেমেন্ট গেটওয়ে ইন্টিগ্রেশন

PHP code start from 13:15 Min.
Video Tutorial Link: https://www.youtube.com/watch?v=0RVALC-D-1U

Source Code: https://github.com/Mominulcse7/bKash_Integration

API Files: https://github.com/Mominulcse7/bKash_Integration/blob/master/BkashApiFile.zip

Keep API file on your hosting & change the credential.  

বিকাশ মার্চেন্ট অ্যাকাউন্ট খুলুনঃ
https://www.bkash.com/bn/i-want-register/send-registration-request
এই লিংক থেকে আইডি খুলুন। তারাই যোগাযোগ করবে।

কিভাবে কাজ করবেন?
১। অ্যান্ড্রয়েড অ্যাপে ইন্টিগ্রেশন এর জন্য সোর্স কোড কপি করুন। BkashActivity.java ফাইলে wvBkashPayment.loadUrl("https://www.hosting.com/api/payment.php"); এই লাইনে আপনার হোস্টিং এর লিংক দিন।
২। হোস্টিং এ API ফাইল গুলো রেখে config_live.php ফাই্লটিতে শুধু মাত্র মার্চেন্ট একাউন্ট এর ইউজার আইডি পাসওয়া্ড পরিবর্তন করুন। আর কোনো পরিবর্তন লাগবে না।  

আরো বিস্তারিত জানতে: https://developer.bka.sh/ 

বিকাশ ইন্টিগ্রেশন
বিকাশ পেমেন্ট গেটওয়ে
বিকাশ অ্যান্ড্রয়েড

bKash Android
bKash php
bKash Payment 
bkash payment gateway

Email: mominulcse7@gmail.com
Facebook: https://www.facebook.com/Siddiqui.mominul/
